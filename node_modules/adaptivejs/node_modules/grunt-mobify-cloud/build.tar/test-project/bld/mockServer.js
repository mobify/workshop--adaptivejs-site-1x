var express = require('express');
var fs = require('fs');
var https = require('https');
var app = express();

// Allow self-signed test certs to work
process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";

// Add options needed to create an https server
var options = {
    key: fs.readFileSync('test/fixtures/test-key.pem'),
    cert: fs.readFileSync('test/fixtures/test-cert.pem')
};

app.post('/api/projects/:project/builds/', function(req, res) {
    var body = '';
    req.on('data', function(data){
        body += data;
    });

    // Write out tar file from request
    req.on('end', function(){
        fs.writeFile('upload.tar', JSON.parse(body)['data'], 'base64', function(err){
            res.send('Got your build!');
        });
    });
});

var server = https.createServer(options, app);

// Grunt-express expects the server to have a use method
// We lost it when calling https.createServer
server.use = app.use;

module.exports = server;