'use strict';

var grunt = require('grunt');
var Utils = require('../lib/utils');
/*
  ======== A Handy Little Nodeunit Reference ========
  https://github.com/caolan/nodeunit

  Test methods:
    test.expect(numAssertions)
    test.done()
  Test assertions:
    test.ok(value, [message])
    test.equal(actual, expected, [message])
    test.notEqual(actual, expected, [message])
    test.deepEqual(actual, expected, [message])
    test.notDeepEqual(actual, expected, [message])
    test.strictEqual(actual, expected, [message])
    test.notStrictEqual(actual, expected, [message])
    test.throws(block, [error], [message])
    test.doesNotThrow(block, [error], [message])
    test.ifError(value)
*/

exports.mobifyUpload = {
    readCredentials: function(test) {
        var creds = Utils.readCredentials('test/fixtures/creds');

        test.equal(creds, 'user@mobify.com:asdf1234');

        test.done();
    },

    buildObject: function (test) {
        var filepath = 'test/fixtures/test.zip';
        var testMessage = 'test message';

        var buildObject = Utils.buildObject(filepath, testMessage);

        var testFile = grunt.file.read(filepath, {encoding: null});
        var base64data = testFile.toString('base64');

        var testObj = {
            message: testMessage,
            encoding: "base64",
            data: base64data
        };

        test.deepEqual(testObj, buildObject);

        test.done();
    },
    buildRequest: function(test) {
        var opts = {
            origin: 'https://cloud-test.mobify.com',
            projectSlug: 'test-project',
            auth: 'test@mobify.com:asdf1234',
            dataLength: 1024
        };

        var expectedPath = '/api/projects/' + opts.projectSlug + '/builds/';

        var request = Utils.buildRequest(opts, test.done);

        test.equal(request.uri.origin, opts.host);
        test.equal(request.uri.path, expectedPath);
        test.equal(request.method, 'POST');

        test.done();
    },
    createArchive: function(test) {
        var files = ['test/fixtures/build.txt'];
        var archivePath = './tmp.tar';
        var projectSlug = 'test-project';
        var expectedOutput = 'bld/fixtures/build.txt';

        function removeTar() {
            grunt.util.spawn({
                cmd: 'rm',
                args: [archivePath]
            }, function done(err, result) {
                if (err) {
                    throw err;
                }
                else {
                    test.done();
                }
            });
        }

        function checkArchiveContents() {
            test.equal(grunt.file.isFile(archivePath), true);

            // Check that the tar contains the right file.
            grunt.util.spawn({
                cmd: 'tar',
                args: ['-tf', archivePath],
            }, function done(err, result) {
                test.ok(result.stdout.indexOf(expectedOutput) > -1);
                removeTar();
            });
        }

        Utils.createArchive(files, projectSlug, archivePath, checkArchiveContents);
    }
};
